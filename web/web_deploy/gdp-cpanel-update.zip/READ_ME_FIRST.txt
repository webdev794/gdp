GROCERLY - update bundle (v7)
=============================
This bundle contains updated CODE ONLY. It has no .env and no installer, so it
will not touch your live configuration or data.

WHAT'S NEW in v7
  - Per-store inventory, rider auto-assignment, admin pagination
  - Web + Expo rider console: chat, picked-up, delivery OTP / override
  - Password sign-up + change / forgot-password (email code)
  - Rider ratings & feedback (admin-only comments) + rider dashboard stats
  - Support-chat rating by the customer
  - Rider "new delivery" alert: email + selectable/uploadable alarm tone

NEW DATABASE OBJECTS (already in your local DB, so your import covers them):
  - table   rider_reviews
  - columns users.rider_rating_avg, users.rider_rating_count
  - columns orders.delivered_at, delivery_verified, delivery_note,
            delivery_code, delivery_code_expires_at
  - columns support_threads.rating, rating_comment, rated_at
  - table   store_inventory ; columns orders.store_id ; rider_* columns on users
            + rider_store pivot (from the v7 base)

STEPS
  1. Back up first: in cPanel download public_html/gdp/  and export the DB.
  2. Import your local database (you're doing this yourself). If instead you
     only want the schema changes on the existing data, run in cPanel > Terminal:
         cd ~/public_html/gdp && php artisan migrate --force
  3. cPanel > File Manager > open  public_html/
     Upload this zip INTO public_html/  and Extract  ->  overwrite when asked.
     (It writes into public_html/gdp/ ; your .env is NOT in the zip.)
  4. Delete stale hashed assets: in  public_html/gdp/assets/  remove files whose
     names are not referenced by the new index.html (old *-<hash>.js / .css).
  5. Delete  public_html/gdp/bootstrap/cache/config.php  (and any *.php there)
     so config re-caches on the next request.
  6. Hard-refresh  https://testcaresortwork.co.in/gdp/  (Ctrl+Shift+R).

Rollback: re-upload your backup of public_html/gdp/ and re-import the DB dump.
